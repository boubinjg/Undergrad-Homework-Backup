#include "RayTracer.h"


RayTracer::RayTracer(FrameBuffer & cBuffer, color defaultColor )
:colorBuffer(cBuffer), defaultColor(defaultColor), recursionDepth(2)
{
	
}


RayTracer::~RayTracer(void)
{
}

void RayTracer::setCameraFrame(const glm::vec3 & viewPosition, const glm::vec3 & viewingDirection, glm::vec3 up)
{
	// Calculate and set the the w, u, and vdata members and 
	// set the eye data member to the viewing position.
	// TODO
	eye = viewPosition;
	w = -viewingDirection;
	u = glm::normalize(glm::cross(up, w));
	v = glm::normalize(glm::cross(w,u));
	glm::vec3 t;
	
} // end setCameraFrame


void RayTracer::calculatePerspectiveViewingParameters(const float verticalFieldOfViewDegrees)
{
	// Set the set the topLimit, bottomLimit, rightLimit, 
	// leftLimit, distToPlane, nx, and ny data members
	// TODO


	//tested and is correct
	nx = colorBuffer.getWindowWidth();
	ny = colorBuffer.getWindowHeight();
	topLimit = 1;
	rightLimit = topLimit * nx / ny;
	bottomLimit = -topLimit;
	leftLimit = -rightLimit;
	distToPlane = topLimit / glm::tan(glm::radians(verticalFieldOfViewDegrees) / 2.0f);

} // end calculatePerspectiveViewingParameters


void RayTracer::calculateOrthographicViewingParameters(const float viewPlaneHeight)
{
	topLimit = fabs(viewPlaneHeight) / 2.0f;

	rightLimit = topLimit * ((float)colorBuffer.getWindowWidth()/colorBuffer.getWindowHeight()); // Set r based on aspect ratio and height of plane

	// Make view plane symetrical about the viewing direction
	leftLimit = -rightLimit; 
	bottomLimit = -topLimit;

	// Calculate the distance between pixels in the horizontal and vertical directions
	nx = (float)colorBuffer.getWindowWidth();
	ny = (float)colorBuffer.getWindowHeight();

	distToPlane = 0.0; // Rays start on the view plane
	
} // end calculateOrthographicViewingParameters


glm::vec2 RayTracer::getProjectionPlaneCoordinates(const int x, const int y)
{
	// Page 75
	// Calculate and return the u and v data members as the x an y coordinates
	// of the 
	glm::vec2 uvScalarValues;
	uvScalarValues.x = (x + .5f) * (rightLimit - leftLimit) / nx + leftLimit;
	uvScalarValues.y = (y + .5f) * (topLimit - bottomLimit) / ny + bottomLimit;
	
	return uvScalarValues;
	//std::cout << uvScalarValues.x << " " << uvScalarValues.y << std::endl;
	
	// TODO
}


void RayTracer::setOrthoRayOriginAndDirection(const int x, const int y)
{
	glm::vec2 uv = getProjectionPlaneCoordinates(x, y);

	// Page 75
	rayDirection = glm::normalize(-w);
	rayOrigin = eye + uv.x * u + uv.y * v;

} // end setOrthoOriginAndDirection


void RayTracer::setPerspectiveRayOriginAndDirection(const int x, const int y)
{
	// TODO
	glm::vec2 uv = getProjectionPlaneCoordinates(x, y);
	rayDirection = glm::normalize(-distToPlane*w + uv.x*u + uv.y*v);
	rayOrigin = eye;

} // end setPerspectiveOriginAndDirection





void RayTracer::raytraceScene(const std::vector<std::shared_ptr<Surface>> & surfaces, const std::vector<std::shared_ptr<LightSource>> & lights, unsigned recDepth)
{
	this->surfacesInScene = surfaces;
	this->lightsInScene = lights;

	// Iterate through each and every pixel in the rendering window
	// TODO
	for (unsigned i = 0; i < WINDOW_WIDTH; ++i) {
		for (unsigned j = 0; j < WINDOW_HEIGHT; ++j) {
			//colorBuffer.setPixel(i,j,defaultColor);
			setPerspectiveRayOriginAndDirection(i,j);
			colorBuffer.setPixel(i,j,traceIndividualRay(rayOrigin, rayDirection, recDepth));
		}
	}
} // end raytraceScene



color RayTracer::traceIndividualRay(const glm::vec3 &e, const glm::vec3 &d, int recursionLevel)
{
	// Find surface intersection that is closest to 'e' in the direction 'd.'
	// TODO
	if (recursionLevel <= 0)
		return color(0, 0, 0, 0);

	HitRecord closest;
	
	closest = findIntersection(e, d, surfacesInScene);
	
	if (closest.t != FLT_MAX) {
		color totalLight(0.0f, 0.0f, 0.0f, 1.0f);
		for (unsigned int i = 0; i < lightsInScene.size(); i++) {
			totalLight += lightsInScene[i]->illuminate(-d, closest, surfacesInScene);
		}
		
		return totalLight + traceIndividualRay(closest.interceptPoint + EPSILON* closest.surfaceNormal, closest.surfaceNormal, recursionLevel-1);
	}
	if (e == rayOrigin)
		return defaultColor;
	else
		return defaultColor * 0.5f;

} // end traceRay