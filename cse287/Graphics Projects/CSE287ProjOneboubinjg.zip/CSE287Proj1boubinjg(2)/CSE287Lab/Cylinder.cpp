#include "Cylinder.h"


Cylinder::Cylinder(const glm::vec3 & position, const color & mat, float a, float b, float c, float h)
	: QuadricSurface(position, mat), height(h)
{
	QuadricSurface::A = a;
	QuadricSurface::B = b;
	QuadricSurface::C = c;
	QuadricSurface::J = -1;
	if (a != 0)
		radius = sqrt(1 / a);
	else
		radius = sqrt(1 / b);
}

Cylinder::~Cylinder()
{

}

HitRecord Cylinder::findClosestIntersection(const glm::vec3 &rayOrigin, const glm::vec3 &rayDirection)
{
	HitRecord hr;
	hr = QuadricSurface::findClosestIntersection(rayOrigin, rayDirection);
	
	if (hr.t == FLT_MAX)
		return hr;

	float pdist;
	if(A == B)
		pdist = abs(hr.interceptPoint.z - center.z);
	else if(A == C)
		pdist = abs(hr.interceptPoint.y - center.y);
	else if(B == C)
		pdist = abs(hr.interceptPoint.x - center.x);

	if (pdist > height)
		hr.t = FLT_MAX;
	return hr;

} // end checkIntercept

