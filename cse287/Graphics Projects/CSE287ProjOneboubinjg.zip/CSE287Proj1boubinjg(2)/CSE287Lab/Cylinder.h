#pragma once
#include "QuadricSurface.h"


class Cylinder : public QuadricSurface
{
public:


	Cylinder(const glm::vec3 & position, const color & mat, float a, float b, float c, float h);
	~Cylinder();
	float height, radius;
	virtual HitRecord findClosestIntersection(const glm::vec3 &rayOrigin, const glm::vec3 &rayDirection);
};

