#include "SimplePoly.h"

/**
* Constructor for the Plane.
*/


SimplePoly::SimplePoly(std::vector<glm::vec3> vertices, const color & material)
	: Plane(vertices, material), points(vertices)
{
	//plane finds the normal vector
}


SimplePoly::~SimplePoly(void)
{
}

/*
* Checks a ray for intersection with the surface. Finds the closest point of intersection
* if one exits. Returns a HitRecord with the t parmeter set to FLT_MAX if there is no
* intersection.
*/
HitRecord SimplePoly::findClosestIntersection(const glm::vec3 &rayOrigin, const glm::vec3 &rayDirection)
{
	HitRecord hr = Plane::findClosestIntersection(rayOrigin, rayDirection);
	if (hr.t == FLT_MAX)
		return hr;
	
	double denom = glm::dot(rayDirection, Plane::n);
	glm::vec3 nsto = Plane::n;
	if (denom > 0) {
		nsto = -Plane::n;
		denom = glm::dot(rayDirection, nsto);
	}

	for (size_t i = 0; i < points.size(); i++) {
		size_t i1 = (i + 1) % points.size();
		glm::vec3 vpos = glm::cross(points[i1] - points[i],
						 hr.interceptPoint-points[i]);

		if (glm::dot(vpos, nsto) <= 0) {
			hr.t = FLT_MAX;
			return hr;
		}
	}
	hr.surfaceNormal = nsto;
	return hr;
} // end checkIntercept

