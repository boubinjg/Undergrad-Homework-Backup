#pragma once

#include "BasicIncludesAndDefines.h"

//struct VertexData {
//
//	glm::vec4 position;
//	color material;
//	glm::vec4 normal;
//
//	VertexData(const glm::vec4 & pos = glm::vec4(0.0, 0.0, 0.0, 0.0),
//		const color & col = color(0.75, 0.75, 0.75, 1.0),
//		const glm::vec4 & norm = glm::vec4(0.0, 0.0, 1.0, 0.0))
//	{
//		position = pos;
//		material = col;
//		normal = glm::normalize(norm);
//	}
//
//};