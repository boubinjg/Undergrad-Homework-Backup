#pragma once

#include <iostream>
#include <vector>
#include <time.h>
#include <memory>

#define GLM_SWIZZLE

#include <GL/freeglut.h>

#include <glm/glm.hpp>

#include <glm/gtx/rotate_vector.hpp>

/*
* Preprocessor statement for text substitution
*/

// Attenuation factors
#define CONSTANT_ATTEN 1.0f
#define LINEAR_ATTEN 0.01f
#define QUADRATIC_ATTEN 0.001f

#define WINDOW_WIDTH 700
#define WINDOW_HEIGHT 500

#define color glm::vec4

#define EPSILON 1.0E-4f

#define PI glm::pi<float>()

color getRandomColor();


void print(const glm::vec2 & v0);

void print(const glm::vec3 & v0);

void print(const glm::vec4 & v0);

void print(const glm::mat2 & m);

void print(const glm::mat3 & m);

void print(const glm::mat4 & m);

// Give three vertices on the face of a polygon in counter clockwise 
// order calculates a normal vector for the polygon.
glm::vec3 findUnitNormal(glm::vec3 pZero, glm::vec3 pOne, glm::vec3 pTwo);

