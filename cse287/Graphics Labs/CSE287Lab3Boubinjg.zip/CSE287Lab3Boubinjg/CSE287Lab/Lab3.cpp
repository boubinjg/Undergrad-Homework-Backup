#include "Lab3.h"
#include<algorithm>

/**
* LAB INSTRUCTIONS:
* Below are descriptions of problems in vector arithmetic and three dimensional
* geometry. Most require you to implement a struct that can be used to
* represent two or three dimensional curves or surfaces.
*
* Coding up these problems gives you a chance to verify your work is correct.
* Test by using values or quantities for which you know the answer.
*
* Please note that BasicIncludes includes overloaded functions called "print"
* for printing vec2, vec3, and vec4 objects to the console. these functions
* are useful for printing vectors and matrices to the console.
*
* Uncomment all function calls before turning in the lab.
* When you have completed all the problems, complete the following turning in
* instructions:
*
*	1.	Copy the folder containing your solution to the desktop.
*	2.	Change the name of the folder to CSE618LabTwo followed by your unique
*		identifier. For instance �CSE618LabTwoBachmaer.�
*	3.	Open the solution. Make sure it still runs.
*	4.	Clean the solution by selecting Build->Clean Solution. (This will delete
*		the intermediate temporary files that are part of your project and
*		reduce the size of your submission.)
*	5.	Zip up the solution folder using the standard windows compression tool.
*		(No 7zips, rars, etc. Just zips.)
*	6.	Submit your zip archive of the solution through canvas.
*
*/

// Complete the constructor and the checkPoint methods for the Circle struct.
// The constructor should assign the input arguments to the data members using an
// initializer list.
// The checkPoint method should return a negative value for points that are inside the
// circle, zero for points that are on the circle, and positive values for points
// that are outside the circle.
// Test the checkPoint function using using the following values:
//   Circle c with center at (0, 0) and radius = 1
//   vec2 p = [0.5 0] (inside circle)
//   vec2 q = [1 0] (on circle)
//   vec2 r = [2 0] (outside circle)
// Then test your function for points of your choosing on a Circle that is NOT
// centered on the origin.
// Display all the results to the console.
struct Circle {

	glm::vec2 center;
	float radius;

	Circle(float r = 1.0, glm::vec2 ctr = glm::vec2(0.0, 0.0)) : radius(r), center(ctr)
	{

	} // end Circle constructor

	float checkPoint(glm::vec2 pt)
	{
		return pow(glm::length(center - pt), 2) - radius * radius;
	} // end checkPoint

}; // end Circle struct


void problem1()
{
	std::cout << "Problem 1" << std::endl;
	Circle c;
	std::cout << "Checking Point .5, 0: should be negative" << std::endl;
	std::cout << c.checkPoint(glm::vec2(.5, 0)) << std::endl;
	std::cout << "Checking point 1,0: should be zero" << std::endl;
	std::cout << c.checkPoint(glm::vec2(1, 0)) << std::endl;
	std::cout << "Checking point 2,0: should be positive " << std::endl;
	std::cout << c.checkPoint(glm::vec2(2, 0)) << std::endl;

	Circle c2(2.0, glm::vec2(1,1));
	std::cout << "Checking Circle centered at 1,1 with radius 2 for point 3,1: should be zero" << std::endl;
	std::cout << c2.checkPoint(glm::vec2(3, 1)) << std::endl;
} // end Problem1

// Create a Sphere struct that is similar to the Circle struct. Again, it should 
// have a constructor with default arguments and an initializer list, and a 
// checkPoint method that returns negative values, zero, and positive values in a 
// manner that is similar to the Circle struct. 
// Test using the following values:
//   Sphere s with center at (0, 0, 0) and radius = 1
//   vec3 p = [0 0.5 0] (inside sphere)
//   vec3 q = [1 0 0] (on sphere)
//   vec3 r = [0 0 4] (outside sphere)
// Then test with points of your choosing that are inside, on, and outside a Sphere 
// that is NOT centered on the origin. Display the results to the console.
struct Sphere {
	glm::vec3 center;
	float radius;

	Sphere(float r = 1.0, glm::vec3 ctr = glm::vec3(0.0, 0.0, 0.0)) : radius(r), center(ctr)
	{

	} // end Circle constructor

	float checkPoint(glm::vec3 pt)
	{
		return pow(glm::length(center - pt), 2) - radius * radius;
	} // end checkPoint

}; // end Sphere struct

void problem2()
{
	std::cout << "Problem 2" << std::endl;
	Sphere s1;
	std::cout << "Checking sphere against point 0,.5, 0: should be negative" << std::endl;
	std::cout << s1.checkPoint(glm::vec3(0,.5, 0)) << std::endl;
	std::cout << "Checking Sphere against point 1,0,0: should be zero" << std::endl;
	std::cout << s1.checkPoint(glm::vec3(1, 0, 0)) << std::endl;
	std::cout << "Checking sphere against point 0,0,4: should be positive" << std::endl;
	std::cout << s1.checkPoint(glm::vec3(0, 0, 4)) << std::endl;

	Sphere s2(2, glm::vec3(1, 1, 1));
	std::cout << "Checking sphere centered at 1,1,1 with radius 2 against point 3,1,1: should be zero" << std::endl;
	std::cout << s2.checkPoint(glm::vec3(3, 1, 1)) << std::endl;
} // end Problem2

// Write a struct for a Quadric surface of your choice. It should include a constructor
// and checkPoint method as in the previous problems. Test the method in a similar 
// manner and display the results.

// Create struct here
struct Cylinder {
	glm::vec3 center;
	float radius, height;

	Cylinder(float r = 1.0, float h = 1.0, glm::vec3 ctr = glm::vec3(0.0, 0.0, 0.0)) : \
		radius(r), height(h), center(ctr) 
	{

	} // end Circle constructor

	float checkPoint(glm::vec3 pt)
	{
		return pow((center.x - pt.x),2)/(radius*radius) + pow((center.y - pt.y), 2) / (height * height) - 1;
	} // end checkPoint

};
void problem3()
{
	std::cout << "Problem 3" << std::endl;
	Cylinder c;
	std::cout << "Checking point 1,0,0 on cylinder at 0,0,0 with radius 1 and height 1: should be zero" << std::endl;
	std::cout << c.checkPoint(glm::vec3(1,0,0)) << std::endl;

} // end Problem3

// Write a Plane struct. The constructor should have three vec3s as parameters
// that are assumed to be in counter-clockwise order. The data members of the 
// struct should include a normal vector and a point on the Plane. The normal
// vector should point out of the side of the Plane on which the vertices are
// in counter-clockwise order and should be unit length. 
//
// As long as the normal vector is a unit vector, the signed distance of a 
// point from a plane is given by the equation on page 57 of the notes. Write
// a signedDistance function that has a vec3 as a parameter. 
// Test it using the following values:
//   Plane p with points (0, 4, 0), (0, 0, 0), (4, 0, 0)
//   vec3 x = [0 0 1] (in front of plane)
//   vec3 y = [0 0 -1] (behind plane)
//   vec3 z = [0 3 0] (on plane)
// Then test it for using points and a new Plane of your choosing. Display  
// all of your results on the console.
//
// Can your checkPoint methods in the previous questions be modified to 
// return a signed distance? If you believe the answer is "yes," go ahead
// and modify the functions accordingly in each of the previous questions.
struct Plane {
	glm::vec3 norm;
	glm::vec3 point;
	float radius, height;
	glm::vec3 p1, p2, p3;
	Plane(glm::vec3 v1, glm::vec3 v2, glm::vec3 v3) : p1(v1), p2(v2), p3(v3)
	{
		norm = glm::cross(v1 - v2, v3 - v2);
		norm = glm::normalize(norm);
	} // end Plane
	float signedDistance(glm::vec3 pt) 
	{
		return glm::dot((p1 - pt), norm);
	}
}; // end Plane struct

void problem4()
{
	std::cout << "Problem 4" << std::endl;
	Plane p(glm::vec3(0, 4, 0), glm::vec3(0, 0, 0), glm::vec3(4, 0, 0));
	std::cout << "Plane p: (0,4,0), (0,0,0), (4,0,0)" << std::endl;
	std::cout << "Testing point (0,0,1) on p: should be negative" << std::endl;
	std::cout << p.signedDistance(glm::vec3(0,0,1)) << std::endl;
	std::cout << "Testing point (0,0,-1) on p: should be positive" << std::endl;
	std::cout << p.signedDistance(glm::vec3(0,0,-1)) << std::endl;
	std::cout << "Testing point (0,3,0) on p: should be zero" << std::endl;
	std::cout << p.signedDistance(glm::vec3(0,3,0)) << std::endl;

	Plane p2(glm::vec3(0, 0, 0), glm::vec3(5, 0, 0), glm::vec3(0, 5, 0));
	std::cout << "Plane p2, (0,0,0), (0,5,0), (5,0,0)" << std::endl;
	std::cout << "testing point (0,1,0) on plane p2: should be zero" << std::endl;
	std::cout << p2.signedDistance(glm::vec3(0, 1, 0)) << std::endl;
} // end Problem4

// Write a struct that supports a parametric representation of a line 
// in three dimensional space. The constructor should take two points on
// the line as parameters. 
//
// It should have a method called checkPoint that returns true if the 
// input argument is on the line and false otherwise. If the point is on 
// the line it should also return the parameter of the point "by reference." 
// Test this method for the following values:
//   ParametricLine with points (0, 0, 0) and (1, 0, 0)
//   Point u = (2, 0, 0) (on line,  returned parameter = 2)
//   Point v = (0, 3, 0) (off line)
// Then test the method with your own values for the line and points.
// Verify that the returned parameter is correct for points on the line. 
// Display the results. 
//
// Write a method called getPoint. Given a value for the parameter, t, it
// should return a vec3 that contains the location that corresponds to the
// supplied parameter. 
//
// Test this method with the same ParametricLine from the checkPoint test and 
// parameter values of 3, -3, and 0.5 (the results should be [3 0 0], 
// [-3 0 0], and [0.5 0 0], respectively).

// Then test the method using your own values for the line and points. Include
// parameters for positive and negative points, as well as a point in between
// the two used to define the line.
// Display the results.
struct ParametricLine {
	glm::vec3 p0, p1;
	glm::vec3 lineVec;
	ParametricLine(glm::vec3 tp0, glm::vec3 tp1) : p0(tp0), p1(tp1) 
	{
		lineVec = glm::normalize(p1 - p0);
	}
	bool checkPoint(const glm::vec3 & p, double & t)
	{
		t = 0.0;
		if (std::abs(glm::dot(lineVec, p - p1)) == glm::length(lineVec) * glm::length(p - p1)) {
			t = glm::length(p0-p) / glm::length(p0-p1);
			return true;
		} else {
			return false;
		}
	}
	glm::vec3 getPoint(float t) {
		return lineVec * t;
	}

}; // end ParametricLine struct

void problem5()
{
	std::cout << "Problem 5" << std::endl;
	ParametricLine p(glm::vec3(0, 0, 0), glm::vec3(1, 0, 0));
	double t;
	std::cout << "checkPoint:" << std::endl;
	std::cout << "Line p: (0,0,0), (1,0,0)" << std::endl;
	std::cout << "Checking point 2,0,0, should be true" << std::endl;
	std::cout << p.checkPoint(glm::vec3(2, 0, 0), t) << std::endl;
	std::cout << "T for point 2,0,0 is:" << std::endl;
	std::cout << t << std::endl;
	std::cout << "Checking T for point 0,3,0" << std::endl;
	std::cout << p.checkPoint(glm::vec3(0, 3, 0), t) << std::endl;

	ParametricLine p2(glm::vec3(0, 0, 0), glm::vec3(0, 0, 2));
	
	std::cout << "Line p2: (0,0,0), (0,0,2)" << std::endl;
	std::cout << "Checking point p (0,0,1)" << std::endl;
	std::cout << p2.checkPoint(glm::vec3(0, 0, 1), t) << std::endl;
	std::cout << "T is: " << t << std::endl;

	std::cout << "getPoint:" << std::endl;
	std::cout << "getPoint 3, -3 and .5 of (1,0,0): " << std::endl;
	print(p.getPoint(3));
	print(p.getPoint(-3));
	print(p.getPoint(.5));
} // end Problem5

// Write a function that supports linear interpolation between
// two scalar (doubles) values. It should take two doubles as 
// arguments. These represent the initial and ending values. It
// should also take a value for the interpolation parameter as 
// an argument. If the parameter is zero or negative, the function
// should return the initial value. If the parameter is one or
// greater, the function should return the final value. Otherwise,
// it should return an interpolated value between the begining 
// and ending values. Use the function to interpolate between 5 and 15.
// Test it with parameter values of -1, 0, 0.6, 1, and 20. Display
// the results to the console.
double linearInterpolateScalars(const double & initial, const double & fin, const double & t)
{
	if (t <= 0)
		return initial;
	else if (t >= 1)
		return fin;
	return initial*(1-t) + fin * (t);

} // end linearInterpolateScalars

void problem6()
{
	std::cout << "Problem 6" << std::endl;
	std::cout << "linearInterpolateScalars(5,15,t) where T is: -1,0,0.6,1,20" << std::endl;
	std::cout << linearInterpolateScalars(5, 15, -1) << std::endl;
	std::cout << linearInterpolateScalars(5, 15, -0) << std::endl;
	std::cout << linearInterpolateScalars(5, 15, .6) << std::endl;
	std::cout << linearInterpolateScalars(5, 15, 1) << std::endl;
	std::cout << linearInterpolateScalars(5, 15, 20) << std::endl;
} // end Problem6

// Write a function that linearly interpolates between two three
// dimension vector values. Functionality should be similar to 
// the previous question. Test it with points at (0,0,0) and (4, 4, 0).
// Use the same parameter values as the previous question. Display the 
// results.
glm::vec3 linearInterpolateVectors(glm::vec3 v1, glm::vec3 v2, const double t)
{
	return glm::vec3(linearInterpolateScalars(std::min(v1.x,v2.x), std::max(v2.x,v2.x), t), 
					 linearInterpolateScalars(std::min(v1.y,v2.y), std::max(v2.y,v2.y), t),
				     linearInterpolateScalars(std::min(v1.z,v2.z), std::max(v2.z,v2.z), t)
					);
}

void problem7()
{
	std::cout << "Problem 7" << std::endl;
	glm::vec3 v1(0,0,0), v2(4,4,0);
	std::cout << "linearInterpolateVectors((0,0,0),(4,4,0),t) where T is: -1,0,0.6,1,20" << std::endl;
	print(linearInterpolateVectors(v1, v2, -1));
	print(linearInterpolateVectors(v1, v2, 0));
	print(linearInterpolateVectors(v1, v2, .6));
	print(linearInterpolateVectors(v1, v2, 1));
	print(linearInterpolateVectors(v1, v2, 20));
} // end Problem7


// Refer to the updated version of slide 37 in the chapter two notes
// for this problem. 
//
// Suppose the vector v = [2 -6 3] and the vector w = [-4 3 10].
// Find the vector that represents the projection of v onto w. Find the
// vector that represents the component of v that is perpendicular to w. Print
// out each of these vectors. Verify correctness by adding together the
// two calculated vectors and checking for equality with v. Also verify the 
// reuslts by taking the dot product of the two vectors. Display the results.
void problem8()
{
	std::cout << "Problem 8" << std::endl;

	glm::vec3 v(2, -6, 3);
	glm::vec3 w(-4, 3, 10);

	glm::vec3 projv = glm::dot(v, w) / pow(glm::length(w), 2) * w;
	glm::vec3 perpw = v - projv;
	std::cout << "The projection of V onto W is:" << std::endl;
	print(projv);
	std::cout << "The component of v perpendicular to w is: " << std::endl;
	print(perpw);
	std::cout << "The previous two vectors added together is: " << std::endl;
	print(perpw + projv);
	std::cout << "V is: " << std::endl;
	print(v);
	std::cout << "The previous vectors added are equal to V" << std::endl;
} // end Problem8




int main(int argc, char** argv)
{
	// To keep the console open on shutdown, start the project with Ctrl+F5 instead of just F5.

	problem1();
	problem2();
	problem3();	
	problem4();	
	problem5();
	problem6();
	problem7();
	problem8();
	
	return 0;

} // end main